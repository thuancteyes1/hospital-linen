// Resilient Vercel entry point.
// If server.ts throws or fails to import for ANY reason (missing env var, bad
// third-party SDK init, etc.), we must still respond with JSON — never let
// Vercel's default HTML/text error page reach the client, since the frontend
// expects JSON from every /api/* call.
import type { IncomingMessage, ServerResponse } from 'http';

export default async function handler(req: IncomingMessage, res: ServerResponse) {
  try {
    const mod = await import('../server.ts');
    const app: any = mod.default;
    return app(req, res);
  } catch (err: any) {
    console.error('Fatal error while loading server.ts:', err);
    if (!res.headersSent) {
      res.statusCode = 500;
      res.setHeader('Content-Type', 'application/json');
    }
    res.end(JSON.stringify({
      error: 'Server failed to initialize',
      details: err?.message || String(err),
    }));
  }
}
